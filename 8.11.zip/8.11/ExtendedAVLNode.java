public class ExtendedAVLNode extends AVLNode {
	private int subtreeKeyCount;

	public ExtendedAVLNode(int nodeKey) {
		super(nodeKey);
		subtreeKeyCount = 1;
	}

	@Override
	public int getSubtreeKeyCount() {
		return subtreeKeyCount;
	}
	
	// Your code here
			public void updateSubtreeKeyCount()
	{
	   int left = 0;
	   int right = 0;
	   
	   if (getLeft() != null)
	   {
	      left = ((ExtendedAVLNode) getLeft()).getSubtreeKeyCount();
	   }
	   if (getRight() != null)
	   {
	      right = ((ExtendedAVLNode) getRight()).getSubtreeKeyCount();
	   }
	   
	   subtreeKeyCount = left + right + 1;
	}
	
	public void updateHeight()
	{
	   super.updateHeight();
	   
	   updateSubtreeKeyCount();
	}
}