public class ExtendedAVLTree extends AVLTree {
	// Each node in an ExtendedAVLTree is an ExtendedAVLNode
	@Override
	protected BSTNode makeNewNode(int key) {
		return new ExtendedAVLNode(key);
	}
	
	// Your code here
	protected void insertNode(BSTNode node)
	{
	   super.insertNode(node);
	   ExtendedAVLNode parent = (ExtendedAVLNode) node.getParent();
	   while (parent != null)
	   {
	      parent.updateSubtreeKeyCount();
	      parent = (ExtendedAVLNode) parent.getParent();
	   }
	}
	
	protected boolean removeNode(BSTNode node)
	{
	   boolean removed = super.removeNode(node);
	   ExtendedAVLNode parent = (ExtendedAVLNode) node.getParent();
	   while (parent != null)
	   {
	      parent.updateSubtreeKeyCount();
	      parent = (ExtendedAVLNode) parent.getParent();
	   }
	   return removed;
	}
	
	protected AVLNode rebalance(AVLNode node)
	{
	   AVLNode newRoot = super.rebalance(node);
	   
	   ExtendedAVLNode extendedRoot = (ExtendedAVLNode) newRoot;
	   extendedRoot.updateSubtreeKeyCount();
	   
	   return extendedRoot;
	}
	
	
	@Override
	public int getNthKey(int n) 
	{
	   ExtendedAVLNode current = (ExtendedAVLNode) getRoot();
	   
	   while (current != null)
	   {
	      int leftCount = 0;
	      if (current.getLeft() != null)
	      {
	         leftCount = ((ExtendedAVLNode) current.getLeft()).getSubtreeKeyCount();
	      }
	      
	      if (n < leftCount)
	      {
	         current = (ExtendedAVLNode) current.getLeft();
	      }else if (n == leftCount)
	      {
	         return current.getKey();
	      }else
	      {
	         n = n - leftCount - 1;
	         current = (ExtendedAVLNode) current.getRight();
	      }
	   }
	   return -1;
	}
}
