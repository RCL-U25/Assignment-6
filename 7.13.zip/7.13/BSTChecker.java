import java.util.*;

public class BSTChecker 
{
	public static Node checkBSTValidity(Node rootNode) 
	{
	   Stack<Node> nodes = new Stack<>();
	   Stack<Integer> minVals = new Stack<>();
	   Stack<Integer> maxVals = new Stack<>();
	   Stack<Set<Node>> ancestors = new Stack<>();
	   
	   nodes.push(rootNode);
	   minVals.push(null);
	   maxVals.push(null);
	   ancestors.push(new HashSet<>());
	   
	   while (!nodes.isEmpty())
	   {
	      Node node = nodes.pop();
	      Integer min = minVals.pop();
	      Integer max = maxVals.pop();
	      Set<Node> seen = ancestors.pop();
	      if (node != null)
	      {
	         if ((min != null && node.key <= min) || (max != null && node.key >= max))
	         {
	            return node;
	         }
	         if (seen.contains(node.left) || seen.contains(node.right))
	         {
	            return node;
	         }
	         
	         Set<Node> updated = new HashSet<>(seen);
	         updated.add(node);
	      
	         nodes.push(node.right);
	         minVals.push(node.key);
	         maxVals.push(max);
	         ancestors.push(updated);
	      
	         nodes.push(node.left);
	         minVals.push(min);
	         maxVals.push(node.key);
	         ancestors.push(updated);
	      }
	   }
	   return null;
	}
}